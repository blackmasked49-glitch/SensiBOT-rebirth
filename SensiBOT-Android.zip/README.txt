SensiBOT Android app (WebView + floating button)
=================================================

What is inside
- app/src/main/assets/index.html   the SensiBOT web app (works offline)
- MainActivity.java                shows the web app and asks for permissions
- FloatingService.java             the floating button + panel over other apps
- AndroidManifest.xml              all permissions the floater needs

Permissions the app asks for (the app shows a screen with an Allow button for each)
1. Display over other apps  - needed for the floating button/panel
2. Notifications            - shows the "floater is on" notice (Android 13+)
3. Run in background        - stops Android from closing the floater (recommended)

BUILD ON YOUR PHONE (no computer) with GitHub
1. Create a free account at github.com and make a new empty repository.
2. In the repo tap  Add file > Create new file.  Name it exactly
       .github/workflows/build.yml
   Paste the text of build.yml (the other file I gave you) and tap Commit.
3. Tap  Add file > Upload files, pick SensiBOT-Android.zip, tap Commit.
4. Open the Actions tab. A run called "Build APK" starts (about 5 minutes).
5. When it is green, open the run, scroll to Artifacts, tap SensiBOT-apk.
6. Unzip the download in your Files app and open app-debug.apk.
   Allow "Install unknown apps" for the app you opened it from when asked.

BUILD ON A COMPUTER
Open this folder in Android Studio and press Build > Build APK(s).

Using the floater
- Tap the round button to open the panel.
- Left side of the panel: scope = AIM STABILIZER / 2X STICKY / AIM BOT switches,
  person = Aim priority (Head / Chest / Default), three lines = HIDE FLOATER.
- Hide floater hides the button; tap the SensiBOT notification (or switch Floating
  SensiBOT off and on in the app) to show it again. The x closes it completely.

What each option does on the phone (nothing touches Free Fire's files or memory)
Phone helpers (they run until you switch them off, then everything goes back to normal):
- Aim Stabilizer / Aim Bot : keep the screen awake, ask Android for the highest refresh rate,
                             close background apps once when switched on
- Optimize Device          : keeps the screen awake
- FPS Booster              : asks Android for the highest refresh rate
- Optimize RAM Memory      : asks Android to end background apps (real memory numbers shown)
- Reduce Freezes           : checks free storage, opens Android's cleanup if nearly full
Sensitivity numbers:
- Low gives a General value of 50-100, +LIGHT 100-150, +STABILIZED 150-200.
- The value inside the range is worked out from the phone: resolution, DPI, screen size,
  refresh rate and an estimate of how many FPS it can hold. +STABILIZED keeps scope values
  steadier (lower at higher zoom), +LIGHT keeps them lighter.
- HeadControl, Aim Stabilizer, 2X Sticky and Aim Bot fine-tune the scope numbers a little.
- None of this touches the game or aims for you.

Matched from the readable manifest of SENSIBOT_1_0.apk
- portrait only, keyboard hidden when a screen opens (the original does the same)
- screens in the original: MainActivity, BotActivity, MoreActivity, WashActivity, DebugActivity
  (settings, AI bot, extras/contact, cleaner, debug). This app has the same screens as tabs.

Updates
- The floating button is the new icon (30% smaller than before). Tap its red X corner to close it,
  tap the rest to open the panel.
- Every time the bot makes (or remakes) a sensitivity it re-reads the phone's real resolution,
  DPI, screen size and refresh rate, so changing the phone's DPI or resolution changes the numbers.

Optional: Shizuku (system tuning with official Android settings only)
- Install the Shizuku app (shizuku.rikka.app), start it (Wireless debugging on Android 11+),
  then open SensiBOT and tap Allow on the "Shizuku (optional)" row of the permission screen.
- While Optimize Device, Aim Stabilizer or Aim Bot is ON, SensiBOT then also runs (each change is read back
  and the app tells you what your phone applied and what it ignored):
    settings put global window_animation_scale / transition_animation_scale / animator_duration_scale 0.5
    settings put secure long_press_timeout 300
    settings put global heads_up_notifications_enabled 0       (no pop-up banners over the game)
    settings put system screen_brightness_mode 0               (brightness stops jumping)
    settings put system min_refresh_rate / peak_refresh_rate <your screen's highest>   (some phones ignore this)
    cmd game mode performance com.dts.freefireth / com.dts.freefiremax   (Android's own Game Mode)
    cmd deviceidle whitelist +com.dts.freefireth / +com.dts.freefiremax (keeps the game out of battery limits)
- Switching the helpers off puts every previous value back (Game Mode back to standard, whitelist removed).
- Nothing here touches Free Fire's files or memory, injects touches, or changes recoil or aim.
  Recoil and weapon spread are part of the game and cannot be removed fairly.

Change DPI (needs Shizuku)
- With Shizuku allowed, the arrow next to the DPI number really changes the phone's screen density
  (same as Developer options > Smallest width) to the next value in your list, skipping any value that
  would make the screen smaller than 300dp wide. Tap the DPI number to go back to the original density.
  If anything ever looks wrong: Settings > Display > Display size, or run  wm density reset.
- The bot re-reads the real DPI and resolution every time it makes a sensitivity, so every DPI and
  every resolution gets its own numbers (a step of about 5 DPI changes at least one value almost always).
- "Generate again" walks through close variants of the best answer instead of random numbers.
