package com.sensibot.app;

import android.animation.ValueAnimator;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.ImageDecoder;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Floating SensiBOT button + panel that stays on top of other apps. */
public class FloatingService extends Service {
    static FloatingService inst;
    static int mode = 0;                          // 0 = Default, 1 = Chest, 2 = Head
    static final boolean[] as = new boolean[3];   // Aim Stabilizer, 2X Sticky, Aim Bot
    static boolean fastHz = false;                // FPS Booster: prefer the highest refresh rate
    static boolean awake = false;                 // Game mode: keep the screen on while the floater is visible

    interface Tap { void on(float x, float y); }

    WindowManager wm;
    ImageView bubble;
    LinearLayout panel;
    Reticle ret;
    TextView[] opts = new TextView[3];
    RailBtn[] rail = new RailBtn[3];
    Sw[] sws = new Sw[3];
    View[] pg = new View[3];                      // pages: 0 = aim assists, 1 = aim priority, 2 = menu
    WindowManager.LayoutParams bp, pp;
    float d;
    View holder;                                  // invisible 1px window that carries keep-awake + refresh-rate hints
    WindowManager.LayoutParams hp;
    boolean panelShown = false, hidden = false, bubbleOn = false, holderOn = false;

    /** Called by the app page when HeadControl changes. */
    static void setMode(final int m) {
        mode = m;
        final FloatingService s = inst;
        if (s != null) new Handler(Looper.getMainLooper()).post(() -> s.apply(m, false));
    }

    /** Called by the app page when an aim-assist switch changes. */
    static void setAssist(final int i, final boolean on) {
        as[i] = on;
        final FloatingService s = inst;
        if (s != null) new Handler(Looper.getMainLooper()).post(() -> s.setAssistUi(i, on));
    }

    /** Helpers (Optimize Device, FPS Booster, Aim Stabilizer, Aim Bot): ask the service to re-check what it should do. */
    static void poke() {
        final FloatingService s = inst;
        if (s != null) new Handler(Looper.getMainLooper()).post(() -> { s.applyHolder(); s.maybeStop(); });
    }

    /** Hides the floating button from the app page (the helpers keep running if they are on). */
    static void bubbleOff() {
        final FloatingService s = inst;
        if (s != null) new Handler(Looper.getMainLooper()).post(() -> { s.hideBubbleViews(); s.maybeStop(); });
    }

    /** Keeps the screen awake and prefers the highest refresh rate while any helper is on. */
    void applyHolder() {
        if (hp == null) return;
        int f = WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
        if (awake) hp.flags |= f; else hp.flags &= ~f;
        float hz = 0;
        if (fastHz) for (Display.Mode m : wm.getDefaultDisplay().getSupportedModes()) hz = Math.max(hz, m.getRefreshRate());
        hp.preferredRefreshRate = hz;
        try {
            boolean need = awake || fastHz;
            if (need && !holderOn) { wm.addView(holder, hp); holderOn = true; }
            else if (!need && holderOn) { wm.removeView(holder); holderOn = false; }
            else if (holderOn) wm.updateViewLayout(holder, hp);
        } catch (Exception e) { /* window not available */ }
    }

    /** Stops the service when nothing needs it any more, which puts the phone back to normal. */
    void maybeStop() {
        if (!bubbleOn && !awake && !fastHz) stopSelf();
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        startFg(); // must be called quickly after startForegroundService
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY; }
        if (inst == null) { init(); inst = this; }
        boolean wantBubble = i != null && i.hasExtra("mode");
        if (wantBubble) mode = i.getIntExtra("mode", 0);
        if (wantBubble || (i != null && "show".equals(i.getAction()))) showBubble();
        apply(mode, false);
        applyHolder();
        maybeStop();
        refreshNotif();
        return START_STICKY;
    }

    @Override public void onDestroy() {
        try { if (bubbleOn && !hidden) wm.removeView(panelShown ? panel : bubble); } catch (Exception e) { /* already gone */ }
        try { if (holderOn) wm.removeView(holder); } catch (Exception e) { /* already gone */ }
        inst = null;
        stopForeground(true);
        super.onDestroy();
    }

    Notification notif() {
        boolean hid = bubbleOn && hidden;
        PendingIntent pi = hid
                ? PendingIntent.getForegroundService(this, 1, new Intent(this, FloatingService.class).setAction("show"), PendingIntent.FLAG_IMMUTABLE)
                : PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        String title = !bubbleOn ? "SensiBOT phone helpers are on"
                : hid ? "SensiBOT floating button is hidden" : "SensiBOT floating button is on";
        return new Notification.Builder(this, "floater")
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(title)
                .setContentText(hid ? "Tap to show it again" : "Tap to open the app")
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("floater", "Floating button", NotificationManager.IMPORTANCE_LOW));
        // 1 << 30 is FOREGROUND_SERVICE_TYPE_SPECIAL_USE (Android 14+)
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, notif(), 1 << 30);
        else startForeground(1, notif());
    }

    void refreshNotif() {
        ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(1, notif());
    }

    int dp(float v) { return Math.round(v * d); }

    int cx(int v, int w) { DisplayMetrics m = getResources().getDisplayMetrics(); return Math.max(0, Math.min(v, m.widthPixels - w)); }

    int cy(int v, int h) { DisplayMetrics m = getResources().getDisplayMetrics(); return Math.max(0, Math.min(v, m.heightPixels - h)); }

    TextView txt(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    GradientDrawable pill(int fill, int stroke, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(radiusDp));
        g.setColor(fill);
        if (stroke != 0) g.setStroke(dp(2), stroke);
        return g;
    }

    void init() {
        d = getResources().getDisplayMetrics().density;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        int type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;

        bubble = new ImageView(this);
        bubble.setImageResource(R.drawable.bubble);
        bp = new WindowManager.LayoutParams(dp(45), dp(45), type, flags, PixelFormat.TRANSLUCENT);
        bp.gravity = Gravity.TOP | Gravity.START;
        bp.x = getResources().getDisplayMetrics().widthPixels - dp(61);
        bp.y = dp(220);
        // tap the red X corner to close, tap anywhere else to open the panel
        drag(bubble, bubble, bp, (x, y) -> {
            if (x > bubble.getWidth() * 0.58f && y < bubble.getHeight() * 0.42f) quit();
            else openPanel();
        });

        buildPanel(type, flags);

        holder = new View(this);
        hp = new WindowManager.LayoutParams(1, 1, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT);
        hp.gravity = Gravity.TOP | Gravity.START;
    }

    void showBubble() {
        if (bubbleOn) { showAll(); return; }
        wm.addView(bubble, bp);
        bubbleOn = true;
        hidden = false;
        panelShown = false;
    }

    /** Removes the floating button / panel (the helpers are not touched). */
    void hideBubbleViews() {
        if (!bubbleOn) return;
        try { if (!hidden) wm.removeView(panelShown ? panel : bubble); } catch (Exception e) { /* already gone */ }
        bubbleOn = false;
        hidden = false;
        panelShown = false;
        showPage(1);
        refreshNotif();
    }

    void buildPanel(int type, int flags) {
        final int MP = LinearLayout.LayoutParams.MATCH_PARENT, WC = LinearLayout.LayoutParams.WRAP_CONTENT;
        int W = Math.min(dp(310), getResources().getDisplayMetrics().widthPixels - dp(16));

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF0B0B0B);
        bg.setCornerRadius(dp(16));
        bg.setStroke(dp(2), 0xFF2A2A2A);
        panel.setBackground(bg);
        panel.setClipToOutline(true);

        // header (drag handle) with minimise and close
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setBackgroundColor(0xFFD1190C);
        h.setPadding(dp(14), dp(6), dp(6), dp(6));
        TextView title = txt("SENSI BOT", 20, 0xFFFFFFFF, true);
        title.setLetterSpacing(0.1f);
        h.addView(title, new LinearLayout.LayoutParams(0, WC, 1f));
        TextView mn = txt("\u2013", 22, 0xFFFFFFFF, false);
        mn.setGravity(Gravity.CENTER);
        mn.setOnClickListener(v -> closePanel());
        h.addView(mn, new LinearLayout.LayoutParams(dp(40), dp(40)));
        TextView cl = txt("\u00D7", 26, 0xFFFFFFFF, false);
        cl.setGravity(Gravity.CENTER);
        cl.setOnClickListener(v -> quit());
        h.addView(cl, new LinearLayout.LayoutParams(dp(40), dp(40)));
        panel.addView(h, new LinearLayout.LayoutParams(MP, WC));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.HORIZONTAL);
        body.setGravity(Gravity.CENTER_VERTICAL);
        body.setPadding(dp(12), dp(12), dp(12), dp(12));

        // left rail: scope = aim assists, person = aim priority, three lines = menu
        LinearLayout rl = new LinearLayout(this);
        rl.setOrientation(LinearLayout.VERTICAL);
        for (int k = 0; k < 3; k++) {
            final int page = k;
            RailBtn r = new RailBtn(this, k);
            r.setOnClickListener(v -> showPage(page));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
            if (k > 0) lp.topMargin = dp(10);
            rl.addView(r, lp);
            rail[k] = r;
        }
        body.addView(rl, new LinearLayout.LayoutParams(WC, WC));

        FrameLayout stack = new FrameLayout(this);

        // page 0: AIM STABILIZER / 2X STICKY / AIM BOT switches
        LinearLayout a = new LinearLayout(this);
        a.setOrientation(LinearLayout.VERTICAL);
        a.setGravity(Gravity.CENTER_VERTICAL);
        String[] an = {"AIM STABILIZER", "2X STICKY", "AIM BOT"};
        for (int k = 0; k < 3; k++) {
            final int i = k;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), 0, dp(10), 0);
            row.setBackground(pill(0xFF141414, 0, 12));
            TextView lb = txt(an[k], 12, 0xFFFFFFFF, true);
            lb.setLetterSpacing(0.05f);
            row.addView(lb, new LinearLayout.LayoutParams(0, WC, 1f));
            Sw s = new Sw(this);
            sws[k] = s;
            row.addView(s, new LinearLayout.LayoutParams(dp(44), dp(24)));
            row.setOnClickListener(v -> toggleAssist(i));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(MP, dp(40));
            if (k > 0) rp.topMargin = dp(8);
            a.addView(row, rp);
        }
        pg[0] = a;

        // page 1: Aim priority (Head / Chest / Default) + animated model
        LinearLayout pr = new LinearLayout(this);
        pr.setOrientation(LinearLayout.HORIZONTAL);
        pr.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(txt("Aim priority", 12, 0xFF9B9B9B, false));
        String[] names = {"HEAD", "CHEST", "DEFAULT"};
        int[] modes = {2, 1, 0};
        for (int k = 0; k < 3; k++) {
            final int m = modes[k];
            TextView o = txt(names[k], 13, 0xFFFFFFFF, true);
            o.setGravity(Gravity.CENTER);
            o.setOnClickListener(v -> apply(m, true));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MP, dp(36));
            lp.topMargin = dp(8);
            col.addView(o, lp);
            opts[m] = o;
        }
        pr.addView(col, new LinearLayout.LayoutParams(dp(100), WC));
        FrameLayout fm = new FrameLayout(this);
        fm.setBackgroundColor(0xFF000000);
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        try {
            Drawable dr = ImageDecoder.decodeDrawable(ImageDecoder.createSource(getResources(), R.raw.hc));
            iv.setImageDrawable(dr);
            if (dr instanceof AnimatedImageDrawable) {
                AnimatedImageDrawable ad = (AnimatedImageDrawable) dr;
                ad.setRepeatCount(AnimatedImageDrawable.REPEAT_INFINITE);
                ad.start();
            }
        } catch (Exception e) { /* picture is optional */ }
        ret = new Reticle(this);
        fm.addView(iv, new FrameLayout.LayoutParams(MP, MP));
        fm.addView(ret, new FrameLayout.LayoutParams(MP, MP));
        LinearLayout.LayoutParams fl = new LinearLayout.LayoutParams(0, dp(89), 1f);
        fl.leftMargin = dp(8);
        pr.addView(fm, fl);
        pg[1] = pr;

        // page 2: menu with "Hide floater"
        LinearLayout mu = new LinearLayout(this);
        mu.setOrientation(LinearLayout.VERTICAL);
        mu.setGravity(Gravity.CENTER);
        TextView hb = txt("HIDE FLOATER", 13, 0xFFFFFFFF, true);
        hb.setGravity(Gravity.CENTER);
        hb.setLetterSpacing(0.06f);
        hb.setBackground(pill(0xFFD1190C, 0, 20));
        hb.setOnClickListener(v -> hideAll());
        mu.addView(hb, new LinearLayout.LayoutParams(MP, dp(40)));
        TextView cap = txt("Hides the floating button. Tap the notification to show it again.", 11, 0xFF9B9B9B, false);
        cap.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(MP, WC);
        cp.topMargin = dp(10);
        mu.addView(cap, cp);
        pg[2] = mu;

        for (int k = 0; k < 3; k++) stack.addView(pg[k], new FrameLayout.LayoutParams(MP, MP));
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(0, dp(150), 1f);
        sl.leftMargin = dp(10);
        body.addView(stack, sl);
        panel.addView(body, new LinearLayout.LayoutParams(MP, WC));

        for (int k = 0; k < 3; k++) sws[k].set(as[k]);
        showPage(1);

        pp = new WindowManager.LayoutParams(W, WC, type, flags, PixelFormat.TRANSLUCENT);
        pp.gravity = Gravity.TOP | Gravity.START;
        drag(h, panel, pp, null);
    }

    void showPage(int k) {
        for (int i = 0; i < 3; i++) {
            pg[i].setVisibility(i == k ? View.VISIBLE : View.GONE);
            rail[i].set(i == k);
        }
    }

    void openPanel() {
        if (panelShown || !bubbleOn) return;
        pp.x = cx(bp.x + dp(45) - pp.width, pp.width);
        pp.y = cy(bp.y, dp(230));
        wm.addView(panel, pp);
        wm.removeView(bubble);
        panelShown = true;
    }

    void closePanel() {
        if (!panelShown) return;
        bp.x = cx(pp.x + pp.width - dp(45), dp(45));
        bp.y = cy(pp.y, dp(45));
        wm.removeView(panel);
        wm.addView(bubble, bp);
        panelShown = false;
    }

    /** Hides the floating windows; the notification stays so it can be shown again. */
    void hideAll() {
        if (hidden || !bubbleOn) return;
        if (panelShown) {
            bp.x = cx(pp.x + pp.width - dp(45), dp(45));
            bp.y = cy(pp.y, dp(45));
        }
        try { wm.removeView(panelShown ? panel : bubble); } catch (Exception e) { /* already gone */ }
        panelShown = false;
        hidden = true;
        showPage(1);
        refreshNotif();
    }

    void showAll() {
        if (!hidden || !bubbleOn) return;
        wm.addView(bubble, bp);
        hidden = false;
        refreshNotif();
    }

    void quit() {
        MainActivity.push("floaterState(false)");
        hideBubbleViews();
        maybeStop();
    }

    void toggleAssist(int i) {
        boolean on = !as[i];
        setAssistUi(i, on);
        MainActivity.push("setA(" + i + "," + on + ",true)");
    }

    void setAssistUi(int i, boolean on) {
        as[i] = on;
        if (sws[i] != null) sws[i].set(on);
    }

    /** Selects Head / Chest / Default and (when tapped here) tells the app page. */
    void apply(int m, boolean user) {
        mode = m;
        if (ret == null) return;
        for (int k = 0; k < 3; k++) {
            opts[k].setBackground(k == m ? pill(0xFFD1190C, 0, 18) : pill(0xFF141414, 0xFF444444, 18));
        }
        ret.to(m);
        if (user) MainActivity.push("setTz(" + m + ")");
    }

    /** Lets a view be dragged around (moving the whole floating window). */
    void drag(final View touch, final View win, final WindowManager.LayoutParams p, final Tap tap) {
        final int[] st = new int[2];
        final float[] dn = new float[2];
        final boolean[] mv = {false};
        touch.setOnTouchListener((v, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: {
                    st[0] = p.x; st[1] = p.y;
                    dn[0] = e.getRawX(); dn[1] = e.getRawY();
                    mv[0] = false;
                    return true;
                }
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - dn[0], dy = e.getRawY() - dn[1];
                    if (Math.abs(dx) + Math.abs(dy) > dp(6)) mv[0] = true;
                    if (mv[0]) {
                        p.x = cx(st[0] + Math.round(dx), win.getWidth());
                        p.y = cy(st[1] + Math.round(dy), win.getHeight());
                        wm.updateViewLayout(win, p);
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP: {
                    if (!mv[0] && tap != null) tap.on(e.getX(), e.getY());
                    return true;
                }
                default:
                    return false;
            }
        });
    }

    /** Rail button: 0 = scope, 1 = person, 2 = three lines. Filled red when selected. */
    class RailBtn extends View {
        final int kind;
        boolean on;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        RailBtn(Context c, int k) { super(c); kind = k; }

        void set(boolean s) { on = s; invalidate(); }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight(), s = 2 * d, r = 10 * d;
            p.setStyle(Paint.Style.FILL);
            p.setColor(on ? 0xFFD1190C : 0xFF0B0B0B);
            c.drawRoundRect(s / 2, s / 2, w - s / 2, h - s / 2, r, r, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(s);
            p.setColor(0xFFD1190C);
            c.drawRoundRect(s / 2, s / 2, w - s / 2, h - s / 2, r, r, p);
            p.setColor(0xFFFFFFFF);
            p.setStrokeWidth(1.8f * d);
            p.setStrokeCap(Paint.Cap.ROUND);
            float x = w / 2, y = h / 2;
            if (kind == 0) {
                c.drawCircle(x, y, 6 * d, p);
                c.drawLine(x, y - 10 * d, x, y - 3 * d, p);
                c.drawLine(x, y + 3 * d, x, y + 10 * d, p);
                c.drawLine(x - 10 * d, y, x - 3 * d, y, p);
                c.drawLine(x + 3 * d, y, x + 10 * d, y, p);
            } else if (kind == 1) {
                c.drawCircle(x, y - 3.5f * d, 3.5f * d, p);
                c.drawArc(new RectF(x - 7 * d, y + 2 * d, x + 7 * d, y + 14 * d), 200, 140, false, p);
            } else {
                for (int i = -1; i <= 1; i++) c.drawLine(x - 7 * d, y + i * 5 * d, x + 7 * d, y + i * 5 * d, p);
            }
        }
    }

    /** Small on/off switch, red when on. */
    class Sw extends View {
        boolean on;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Sw(Context c) { super(c); }

        void set(boolean v) { on = v; invalidate(); }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            p.setStyle(Paint.Style.FILL);
            p.setColor(on ? 0xFFD1190C : 0xFF3A3A3A);
            c.drawRoundRect(0, 0, w, h, h / 2, h / 2, p);
            p.setColor(0xFFFFFFFF);
            c.drawCircle(on ? w - h / 2 : h / 2, h / 2, h / 2 - 3 * d, p);
        }
    }

    /** The thin red corner square (with red tint) that moves between Default / Chest / Head. */
    static class Reticle extends View {
        final float[][] RT = {{.02f, .03f, .96f, .94f}, {.31f, .30f, .38f, .40f}, {.35f, .03f, .28f, .32f}};
        final float[] cur = {.02f, .03f, .96f, .94f};
        float tint = 0;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Reticle(Context c) { super(c); }

        void to(final int m) {
            final float[] a = cur.clone();
            final float t0 = tint, t1 = m == 0 ? 0f : 0.25f;
            ValueAnimator v = ValueAnimator.ofFloat(0f, 1f);
            v.setDuration(650);
            v.setInterpolator(new OvershootInterpolator(1.1f));
            v.addUpdateListener(an -> {
                float f = (float) an.getAnimatedValue();
                for (int i = 0; i < 4; i++) cur[i] = a[i] + (RT[m][i] - a[i]) * f;
                tint = t0 + (t1 - t0) * f;
                invalidate();
            });
            v.start();
        }

        @Override protected void onDraw(Canvas c) {
            float W = getWidth(), H = getHeight();
            float x = W * cur[0], y = H * cur[1], w = W * cur[2], h = H * cur[3];
            float dn = getResources().getDisplayMetrics().density;
            if (tint > 0) {
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFFD9180B);
                p.setAlpha((int) (Math.min(1f, Math.max(0f, tint)) * 255));
                c.drawRect(x, y, x + w, y + h, p);
            }
            p.setStyle(Paint.Style.STROKE);
            p.setColor(0xFFFF4332);
            p.setAlpha(255);
            p.setStrokeWidth(1.5f * dn);
            float L = 9 * dn;
            Path q = new Path();
            q.moveTo(x + L, y); q.lineTo(x, y); q.lineTo(x, y + L);
            q.moveTo(x + w - L, y); q.lineTo(x + w, y); q.lineTo(x + w, y + L);
            q.moveTo(x, y + h - L); q.lineTo(x, y + h); q.lineTo(x + L, y + h);
            q.moveTo(x + w - L, y + h); q.lineTo(x + w, y + h); q.lineTo(x + w, y + h - L);
            c.drawPath(q, p);
        }
    }
}
