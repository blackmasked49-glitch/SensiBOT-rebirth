package com.sensibot.app;

import android.app.ActivityManager;
import android.app.NotificationManager;
import android.content.ContentResolver;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.os.Environment;
import android.os.StatFs;
import android.util.DisplayMetrics;
import android.view.Display;
import org.json.JSONObject;
import java.util.HashSet;
import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/** Shows the SensiBOT web app and exposes the permission / floater functions to it. */
public class MainActivity extends Activity {
    static MainActivity INST;
    WebView web;

    /** Runs a JavaScript snippet inside the app page (used by the floater to stay in sync). */
    static void push(final String js) {
        final MainActivity a = INST;
        if (a != null && a.web != null) a.web.post(() -> a.web.evaluateJavascript(js, null));
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        INST = this;
        getWindow().setStatusBarColor(0xFF050505);
        getWindow().setNavigationBarColor(0xFF080808);
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "SensiNative");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onDestroy() {
        if (INST == this) INST = null;
        super.onDestroy();
    }

    @Override public void onBackPressed() { moveTaskToBack(true); }

    void go(final Intent i) {
        runOnUiThread(() -> {
            try { startActivity(i); }
            catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
        });
    }


    String ver(String pkg) {
        try {
            String v = getPackageManager().getPackageInfo(pkg, 0).versionName;
            return v == null ? "installed" : v;
        } catch (Exception e) { return ""; }
    }

    long availMb() {
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        ((ActivityManager) getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi);
        return mi.availMem >> 20;
    }

    /** True when a shell command printed an error instead of doing its job. */
    static boolean bad(String r) {
        String x = r.toLowerCase();
        return x.startsWith("err") || x.contains("exception") || x.contains("unknown command") || x.contains("error");
    }

    /** Compares two setting values, numerically when possible ("0.5" == "0.50"). */
    static boolean same(String a, String b) {
        try { return Math.abs(Float.parseFloat(a.trim()) - Float.parseFloat(b.trim())) < 0.01f; }
        catch (Exception e) { return a.trim().equals(b.trim()); }
    }

    /** Functions the web page can call as window.SensiNative.xxx() */
    class Bridge {
        @JavascriptInterface public boolean hasOverlay() { return Settings.canDrawOverlays(MainActivity.this); }

        @JavascriptInterface public boolean hasNotif() {
            return Build.VERSION.SDK_INT < 33
                    || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        }

        @JavascriptInterface public boolean hasBattery() {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            return pm.isIgnoringBatteryOptimizations(getPackageName());
        }

        @JavascriptInterface public void askOverlay() {
            go(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        }

        @JavascriptInterface public void askNotif() {
            if (Build.VERSION.SDK_INT >= 33)
                runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1));
        }

        @JavascriptInterface public void askBattery() {
            go(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
        }

        @JavascriptInterface public void appSettings() {
            go(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
        }

        @JavascriptInterface public void startFloater(int mode) {
            Intent i = new Intent(MainActivity.this, FloatingService.class);
            i.putExtra("mode", mode);
            startForegroundService(i);
        }

        @JavascriptInterface public void stopFloater() { FloatingService.bubbleOff(); }

        @JavascriptInterface public void setMode(int m) { FloatingService.setMode(m); }

        @JavascriptInterface public void setAssist(int i, boolean on) { FloatingService.setAssist(i, on); }

        /** Opens one of Android's own settings pages. */
        @JavascriptInterface public void openSetting(String k) {
            String a;
            switch (k) {
                case "dev": a = Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS; break;
                case "access": a = Settings.ACTION_ACCESSIBILITY_SETTINGS; break;
                case "display": a = Settings.ACTION_DISPLAY_SETTINGS; break;
                case "saver": a = Settings.ACTION_BATTERY_SAVER_SETTINGS; break;
                case "storage": a = Settings.ACTION_INTERNAL_STORAGE_SETTINGS; break;
                default: a = Settings.ACTION_SETTINGS;
            }
            go(new Intent(a));
        }

        /**
         * Optimize Device, FPS Booster, Aim Stabilizer and Aim Bot: keep the screen awake and ask Android for the
         * highest refresh rate. Everything goes back to normal as soon as both are switched off.
         */
        @JavascriptInterface public String helpers(boolean awake, boolean fast) {
            FloatingService.awake = awake;
            FloatingService.fastHz = fast;
            if (awake || fast) startForegroundService(new Intent(MainActivity.this, FloatingService.class));
            else FloatingService.poke();
            Display dsp = getWindowManager().getDefaultDisplay();
            float max = 0;
            for (Display.Mode m : dsp.getSupportedModes()) max = Math.max(max, m.getRefreshRate());
            PowerManager pw = (PowerManager) getSystemService(POWER_SERVICE);
            return "{\"hz\":" + dsp.getRefreshRate() + ",\"maxHz\":" + max + ",\"saver\":" + pw.isPowerSaveMode() + "}";
        }

        /** -1 = Shizuku not installed, 0 = installed but not running, 1 = running but not allowed, 2 = ready. */
        @JavascriptInterface public int shizukuState() {
            if (ShizukuHelper.running()) return ShizukuHelper.granted() ? 2 : 1;
            try { getPackageManager().getPackageInfo("moe.shizuku.privileged.api", 0); return 0; }
            catch (Exception e) { return -1; }
        }

        @JavascriptInterface public void askShizuku() {
            int st = shizukuState();
            if (st == 1) { runOnUiThread(ShizukuHelper::request); return; }
            Intent i = st == 0 ? getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api") : null;
            if (i == null) i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"));
            go(i);
        }

        /**
         * System tuning with Shizuku. Only official Android settings and services are used, nothing touches the game:
         * faster animations, shorter touch-and-hold delay, no pop-up banners over the game, steady brightness,
         * a locked refresh rate, Android's own "performance" Game Mode, and keeping Free Fire out of Doze.
         * Every previous value is saved and put back when this is switched off. Each change is read back, so the
         * answer says what really got applied and what the phone ignored.
         */
        @JavascriptInterface public String tune(boolean on) {
            if (!ShizukuHelper.granted()) return "{\"ok\":false}";
            SharedPreferences sp = getSharedPreferences("sb", MODE_PRIVATE);
            float max = 60;
            for (Display.Mode m : getWindowManager().getDefaultDisplay().getSupportedModes()) max = Math.max(max, m.getRefreshRate());
            String hz = String.valueOf(Math.round(max));
            String[][] keys = {  // namespace, key, value, label
                    {"global", "window_animation_scale", "0.5", "Faster animations"},
                    {"global", "transition_animation_scale", "0.5", "Faster animations"},
                    {"global", "animator_duration_scale", "0.5", "Faster animations"},
                    {"secure", "long_press_timeout", "300", "Shorter touch-and-hold delay"},
                    {"global", "heads_up_notifications_enabled", "0", "No pop-up banners over the game"},
                    {"system", "screen_brightness_mode", "0", "Steady brightness"},
                    {"system", "min_refresh_rate", hz, "Locked refresh rate"},
                    {"system", "peak_refresh_rate", hz, "Locked refresh rate"}};
            String[] games = {"com.dts.freefireth", "com.dts.freefiremax"};
            java.util.LinkedHashMap<String, Boolean> res = new java.util.LinkedHashMap<>();
            if (on) {
                if (!sp.contains("tuned")) {
                    SharedPreferences.Editor e = sp.edit();
                    for (String[] k : keys) e.putString("prev_" + k[0] + "_" + k[1], ShizukuHelper.run("settings get " + k[0] + " " + k[1]));
                    e.putBoolean("tuned", true).apply();
                }
                for (String[] k : keys) {
                    ShizukuHelper.run("settings put " + k[0] + " " + k[1] + " " + k[2]);
                    boolean ok = same(ShizukuHelper.run("settings get " + k[0] + " " + k[1]), k[2]);
                    Boolean old = res.get(k[3]);
                    res.put(k[3], old == null ? ok : old && ok);
                }
                boolean any = false, gm = false, wl = false;
                for (String g : games) {
                    if (ver(g).isEmpty()) continue;
                    any = true;
                    if (!bad(ShizukuHelper.run("cmd game mode performance " + g))) gm = true;
                    if (ShizukuHelper.run("cmd deviceidle whitelist").contains(g)) { wl = true; continue; }
                    if (!bad(ShizukuHelper.run("cmd deviceidle whitelist +" + g))) { sp.edit().putBoolean("wl_" + g, true).apply(); wl = true; }
                }
                if (any) { res.put("Android Game Mode: performance", gm); res.put("Free Fire kept out of battery limits", wl); }
            } else if (sp.contains("tuned")) {
                SharedPreferences.Editor e = sp.edit();
                for (String[] k : keys) {
                    String pk = "prev_" + k[0] + "_" + k[1];
                    String v = sp.getString(pk, "null").trim();
                    boolean unset = v.isEmpty() || v.equals("null") || bad(v);
                    ShizukuHelper.run(unset ? "settings delete " + k[0] + " " + k[1] : "settings put " + k[0] + " " + k[1] + " " + v);
                    e.remove(pk);
                }
                for (String g : games) {
                    if (ver(g).isEmpty()) continue;
                    ShizukuHelper.run("cmd game mode standard " + g);
                    if (sp.getBoolean("wl_" + g, false)) { ShizukuHelper.run("cmd deviceidle whitelist -" + g); e.remove("wl_" + g); }
                }
                e.remove("tuned").apply();
            }
            StringBuilder done = new StringBuilder(), failed = new StringBuilder();
            for (java.util.Map.Entry<String, Boolean> en : res.entrySet()) {
                StringBuilder t = en.getValue() ? done : failed;
                if (t.length() > 0) t.append(",");
                t.append("\"").append(en.getKey()).append("\"");
            }
            return "{\"ok\":true,\"done\":[" + done + "],\"failed\":[" + failed + "]}";
        }

        /**
         * Changes the phone's real screen density (Developer options > Smallest width) with Shizuku.
         * The original density is remembered so resetDpi() can put it back.
         */
        @JavascriptInterface public String setDpi(int dpi) {
            if (!ShizukuHelper.granted() || dpi < 200 || dpi > 900) return "{\"ok\":false}";
            SharedPreferences sp = getSharedPreferences("sb", MODE_PRIVATE);
            if (!sp.contains("orig_dpi")) {
                String out = ShizukuHelper.run("wm density"); // "Physical density: 420" (+ "Override density: 480")
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("Physical density:\\s*(\\d+)").matcher(out);
                sp.edit().putInt("orig_dpi", m.find() ? Integer.parseInt(m.group(1)) : 0).apply();
            }
            String r = ShizukuHelper.run("wm density " + dpi);
            return "{\"ok\":" + !r.startsWith("ERR") + "}";
        }

        @JavascriptInterface public String resetDpi() {
            if (!ShizukuHelper.granted()) return "{\"ok\":false}";
            ShizukuHelper.run("wm density reset");
            getSharedPreferences("sb", MODE_PRIVATE).edit().remove("orig_dpi").apply();
            return "{\"ok\":true}";
        }

        /** Asks Android to end background processes of other user apps (the normal "RAM cleaner" API). */
        @JavascriptInterface public String killBackground() {
            long before = availMb();
            ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            PackageManager pm = getPackageManager();
            Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            ResolveInfo hr = pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY);
            String homePkg = hr != null ? hr.activityInfo.packageName : "";
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            HashSet<String> seen = new HashSet<>();
            int n = 0;
            for (ResolveInfo r : pm.queryIntentActivities(q, 0)) {
                String p = r.activityInfo.packageName;
                boolean system = (r.activityInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                if (!seen.add(p) || system || p.equals(getPackageName()) || p.equals(homePkg) || p.startsWith("com.dts.freefire")) continue;
                am.killBackgroundProcesses(p);
                n++;
            }
            try { Thread.sleep(700); } catch (InterruptedException e) { /* ignore */ }
            return "{\"n\":" + n + ",\"before\":" + before + ",\"after\":" + availMb() + "}";
        }

        /** Reads what Android lets any app read about this phone. */
        @JavascriptInterface public String deviceInfo() {
            try {
                JSONObject o = new JSONObject();
                o.put("model", Build.MANUFACTURER + " " + Build.MODEL);
                o.put("android", Build.VERSION.RELEASE);
                o.put("soc", Build.VERSION.SDK_INT >= 31 ? Build.SOC_MODEL : Build.HARDWARE);
                o.put("cores", Runtime.getRuntime().availableProcessors());
                ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                o.put("ramTotal", mi.totalMem >> 20);
                o.put("ramFree", mi.availMem >> 20);
                DisplayMetrics dm = getResources().getDisplayMetrics();
                o.put("dpi", dm.densityDpi);
                o.put("w", Math.max(dm.widthPixels, dm.heightPixels));
                o.put("h", Math.min(dm.widthPixels, dm.heightPixels));
                o.put("inch", Math.sqrt(Math.pow(dm.widthPixels / dm.xdpi, 2) + Math.pow(dm.heightPixels / dm.ydpi, 2)));
                Display dsp = getWindowManager().getDefaultDisplay();
                float max = 0;
                for (Display.Mode m : dsp.getSupportedModes()) max = Math.max(max, m.getRefreshRate());
                o.put("hz", dsp.getRefreshRate());
                o.put("maxHz", max);
                Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                if (b != null) {
                    o.put("batt", b.getIntExtra("level", 0) * 100 / Math.max(1, b.getIntExtra("scale", 100)));
                    o.put("charging", b.getIntExtra("plugged", 0) != 0);
                    o.put("temp", b.getIntExtra("temperature", 0) / 10.0);
                }
                PowerManager pw = (PowerManager) getSystemService(POWER_SERVICE);
                o.put("saver", pw.isPowerSaveMode());
                o.put("thermal", Build.VERSION.SDK_INT >= 29 ? pw.getCurrentThermalStatus() : 0);
                StatFs sf = new StatFs(Environment.getDataDirectory().getPath());
                o.put("storFree", sf.getAvailableBytes() >> 20);
                o.put("storTotal", sf.getTotalBytes() >> 20);
                ContentResolver cr = getContentResolver();
                o.put("pointer", Settings.System.getInt(cr, "pointer_speed", 0));
                o.put("longPress", Settings.Secure.getInt(cr, "long_press_timeout", 400));
                o.put("anim", Settings.Global.getFloat(cr, Settings.Global.ANIMATOR_DURATION_SCALE, 1f));
                o.put("ff", ver("com.dts.freefireth"));
                o.put("ffmax", ver("com.dts.freefiremax"));
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface public boolean openGame(String pkg) {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) return false;
            go(i);
            return true;
        }
    }
}
