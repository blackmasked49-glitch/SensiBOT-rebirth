package com.sensibot.app;

import android.content.pm.PackageManager;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;

import rikka.shizuku.Shizuku;

/** Small wrapper around Shizuku. Everything fails quietly when Shizuku is missing, stopped or not allowed. */
final class ShizukuHelper {
    static final int REQ = 7301;

    private ShizukuHelper() {}

    static boolean running() {
        try { return Shizuku.pingBinder(); } catch (Throwable t) { return false; }
    }

    static boolean granted() {
        try {
            return running() && !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) { return false; }
    }

    static void request() {
        try { if (running() && !Shizuku.isPreV11()) Shizuku.requestPermission(REQ); } catch (Throwable t) { /* ignore */ }
    }

    /** Runs one shell command with Shizuku's rights and returns its output (or "ERR: ..."). */
    static String run(String cmd) {
        try {
            Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
            m.setAccessible(true);
            Process p = (Process) m.invoke(null, new String[]{"sh", "-c", cmd}, null, null);
            String out = read(p.getInputStream());
            String err = read(p.getErrorStream());
            p.waitFor();
            return (out + err).trim();
        } catch (Throwable t) {
            return "ERR: " + t;
        }
    }

    private static String read(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] x = new byte[4096];
        int n;
        while ((n = in.read(x)) > 0) b.write(x, 0, n);
        return b.toString();
    }
}
